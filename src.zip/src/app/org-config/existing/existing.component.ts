import { CommonService } from './../../common.service';
import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-existing',
  templateUrl: './existing.component.html'
})
export class ExistingComponent implements OnInit {
  listedEntitiesArray: Array<any> = [];
  columnDefs = [
    { headerName: 'Entity Name', field: 'Org_Name'},
    { headerName: 'Address', field: 'Address_Details.Address'},
    { headerName: 'Business Unit Name', field: 'bUnitName'},
    { headerName: 'Business Unit Code', field: 'bUnitCode' },
    { headerName: 'Business Division Name', field: 'bDivisionName'},
    { headerName: 'Business Division Code', field: 'bDivisionCode' },
    { headerName: 'Accounts' , cellRenderer: function(params) {
      return '<span class="grid-button-class"><button class="btn btn-primary">Open</button><span></span></span>';

          }}
  ];
  constructor(private _commonService: CommonService) { }

  ngOnInit() {
    this.listedEntitiesArray = this._commonService.businessEntitiesDetails;
  }

  showAccounts() {
    console.log('Clicked Accounts');
  }

}
