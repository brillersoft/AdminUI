import { CommonService } from './../../common.service';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

export interface Team {
  name: any;
  code: any;
  desc: any;
}
@Component({
  selector: 'app-business-config',
  templateUrl: './business-hierarchy.component.html'
})
export class BusinessHierarchyComponent implements OnInit {
  requestParam: any = {};
  showDivision: Array<Number> = [1, 0, 0, 0, 0, 0];
  teams: Array<Team> = [{name: '', code: '', desc: ''}];
  templateObject: any = {'unit_name': '', 'unit_desc': '', 'unit_code': ''};

  allBusinessUnit: Array<any> = [this.templateObject];

  allBusinessDivision: Array<any> = [this.templateObject];

  allAccounts: Array<any> = [this.templateObject];

  allBusinessGroup: Array<any> = [this.templateObject];

  allTeams: Array<any> = [this.templateObject];
  constructor(
    private router: Router,
    private commonService: CommonService
    ) {  }

  ngOnInit() {
    this.requestParam['division'] = [this.allBusinessUnit];
  }

  saveBusinessUnitDetails() {
    this.commonService.postData('saveBusinessUnitDetails', this.requestParam).subscribe(res => {
      if (res) {
        alert('Details Saved');
      } else {
        this.commonService.showHttpErrorMsg();
      }
    });
  }

  addNew(type: any) {
    switch (type) {
      case 'bUnit':
      this.allBusinessUnit.push(this.templateObject);
        break;
      case 'division':
      this.allBusinessDivision.push(this.templateObject);
          break;
      case 'account':
      this.allAccounts.push(this.templateObject);
          break;
      case 'bGroup':
      this.allBusinessGroup.push(this.templateObject);
          break;
      case 'team':
      this.allTeams.push(this.templateObject);
              break;
      default:
        break;
    }
  }
}
