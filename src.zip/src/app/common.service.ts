import { Injectable } from '@angular/core';
import { Http, Headers, RequestOptions } from '@angular/http';
import { Subject } from 'rxjs';
@Injectable({
  providedIn: 'root'
})
export class CommonService {
  public businessEntitiesDetails: Array<any> = [
    {'Org_Name': 'ABC',
    'Address_Details': {
      'Address': 'Sec-142',
      'Address_Type': 'Internal',
      'City': 'Abohar',
      'Country': 'Austria',
      'District': 'AD',
      'State': 'Uttar Pradesh',
      'Zip': '474006'
      }, 'bUnitName': 'A', 'bUnitCode': '10', 'bDivisionName': 'P', 'bDivisionCode': 'P10' },
    {'Org_Name': 'XYZ', 'Address': 'Sec-142', 'bUnitName': 'X', 'bUnitCode': '11', 'bDivisionName': 'P', 'bDivisionCode': 'P11' },
    {'Org_Name': 'PQR', 'Address': 'Sec-142', 'bUnitName': 'Y', 'bUnitCode': '12', 'bDivisionName': 'P', 'bDivisionCode': 'P12' }
  ];

  public allCountryList: Array<String> = [];
  public allCitiesList: Array<String> = [];
  public headers: any;
  public requestOptions: any;
  public toggleNav = true;
  public baseServiceUrl: any = 'http://172.16.16.40:7070/';
  constructor(private _http: Http) {
    this.headers = new Headers({
      'Content-Type': 'application/json'
    });
    this.requestOptions = new RequestOptions({ headers: this.headers });

   }
  fetchData(serviceName) {
    return this._http.get(this.baseServiceUrl + serviceName);
  }
  postData(serviceName, params) {
    return this._http.post(this.baseServiceUrl + serviceName, params, this.requestOptions);
  }
  showHttpErrorMsg() {
    alert('Oops! Something went wrong while getting data from server.');
  }
}
