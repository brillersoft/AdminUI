import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { Location } from '@angular/common';

@Component({
  selector: 'app-side-nav',
  templateUrl: './side-nav.component.html'
})
export class SideNavComponent implements OnInit {
  showSubList = false;
  constructor(private router: Router, private location: Location) { }

  ngOnInit() {
    this.router.events.subscribe((val) => {
      const route = this.location.path();
      if (route === '/org-config/new' || route === '/org-config/existing-list') {
        this.showSubList = true;
      }
    });
  }

  showSubListMenu() {
    if (this.showSubList === false) {
      this.showSubList = true;
      this.router.navigateByUrl('/');
    } else {
      this.showSubList = false;
    }
  }

}
